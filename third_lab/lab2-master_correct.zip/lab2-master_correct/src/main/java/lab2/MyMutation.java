package lab2;

import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import java.util.List;
import java.util.Random;

public class MyMutation implements EvolutionaryOperator<double[]> {
    public List<double[]> apply(List<double[]> population, Random random) {

        double mutationPercent = 0.99;
        System.out.println("Population - " + population);
        // initial population

        for (int i=0;i < population.size();i++) {
            if (random.nextDouble() < mutationPercent) {
                int index = random.nextInt(population.size());
                double[] element = new double[1];
                element[0] = Math.random() * 5 - 5;
                population.set(index, element);;
            }
        }
        System.out.println("Population - " + population);
        // need to change individuals, but not their number!

        // your implementation:

        //result population
        return population;
    }
}
