package lab2;

import org.uncommons.watchmaker.framework.operators.AbstractCrossover;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MyCrossover extends AbstractCrossover<double[]> {
    protected MyCrossover() {
        super(1);
    }

    protected List<double[]> mate(double[] p1, double[] p2, int i, Random random) {
        List<double[]> children = new ArrayList<double[]>();
        // your implementation:
        int half = p1.length / 2;
        double[] gen1 = new double[half];
        double[] gen2 = new double[half];
        System.out.println("length - " + gen2.length + ' ' + p1.length);
        for (int j=0;j<p1.length;j++) {

            if (j < half) {
                gen1[j] = p1[j];
            }
            else {
                gen2[j - half] = p2[j];
            }
        }
        children.add(gen1);
        children.add(gen2);
        System.out.println("Children - " + children);
        return children;
    }
}
