package lab2;

import org.uncommons.watchmaker.framework.factories.AbstractCandidateFactory;

import java.util.Random;

public class MyFactory extends AbstractCandidateFactory<double[]> {

    private int dimension;

    public MyFactory(int dimension) {
        this.dimension = dimension;
    }

    public double[] generateRandomCandidate(Random random) {
        double[] solution = new double[dimension];
        for (int i=0;i<dimension;i++) {
            solution[i] = Math.random() * 5 - 5;
        }
        // for (int i = 0; i < solution.length; i++) {
        //    System.out.println("Random initialization" +  solution[i]);
        //}
        // x from -5.0 to 5.0

        // your implementation:

        return solution;
    }
}

